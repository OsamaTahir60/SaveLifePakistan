
class Images {

  Images._();

  static const String biacooLogoWhite = "assets/logos/biacoowhite.svg";

}